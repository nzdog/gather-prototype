# Plan Build Spec v1.0

## For Implementation

**Version:** 1.0
**Date:** January 2025
**Source:** Plan Protocol (walked), Plan AI Protocol (walked)
**Scope:** Plan phase of Gather — from event creation through transition to Confirming

---

## Pre-Implementation Checklist

Before writing code, verify:

- [ ] Plan Protocol (6 themes) reviewed
- [ ] Plan AI Protocol (6 themes) reviewed
- [ ] Plan Protocol Laws understood and testable
- [ ] Data model supports all required states
- [ ] AI integration points mapped to Plan AI Protocol governance

---

## 1. Overview

### What This Spec Covers

The Plan phase: where a Host (or Co-Host pair) creates the complete coordination structure for a gathering before Coordinators and Participants are invited.

### What This Spec Does Not Cover

- Confirming phase (Coordinator assignment, Participant invitations)
- Frozen phase (execution lockdown)
- Live phase (day-of coordination)
- Completed phase (post-event)

### Core Workflow

```
Event Creation → Structure Generation → Refinement → Gate Check → Transition
     ↓                   ↓                  ↓             ↓            ↓
  Theme 1            Theme 2            Theme 3       Theme 5      Confirming
                                        Theme 4
                                        Theme 6
```

---

## 2. Design Laws

These laws are non-negotiable. Violations must be caught in code review.

| Law | Enforcement |
|-----|-------------|
| **No Silent Zero** | Fields have explicit states: `unspecified \| none \| specified`. Never default to 0. |
| **Check Plan is diagnostic, not coercive** | Check Plan returns conflicts; only Gate Check blocks transition. |
| **Regeneration must be previewable and reversible** | Diff preview required; revision history with undo. |
| **Acknowledgements are immutable but supersedable** | No edit/delete; only supersede with new record. |
| **Structure changes after transition are controlled** | Post-gate edits require reason + impact diff + notification. |
| **Memory serves coherence, not habit** | Divergence surfaced; fossilisation detected; adaptation prompted. |

---

## 3. Data Model

### 3.1 Event

```typescript
interface Event {
  id: uuid;
  name: string;
  occasionType: 'christmas' | 'thanksgiving' | 'easter' | 'wedding' | 'birthday' | 'reunion' | 'retreat' | 'other';
  occasionDescription: string | null;  // if occasionType = 'other'
  status: 'draft' | 'confirming' | 'frozen' | 'live' | 'completed';
  
  // Ownership
  createdBy: uuid;  // Host ID
  coHost: uuid | null;
  
  // Guest parameters
  guestCount: number | null;
  guestCountConfidence: 'high' | 'medium' | 'low';
  guestCountRange: { min: number; max: number } | null;
  
  // Dietary
  dietaryStatus: 'unspecified' | 'none' | 'specified';
  dietary: {
    vegetarian: number;
    vegan: number;
    glutenFree: number;
    dairyFree: number;
    allergies: string | null;
  } | null;
  
  // Venue
  venue: {
    name: string;
    type: 'home' | 'hired_venue' | 'outdoor' | 'mixed' | 'other';
    kitchenAccess: 'full' | 'limited' | 'none' | 'catering_only';
    ovenCount: number;
    stovetopBurners: number | null;  // v1.1
    bbqAvailable: boolean | null;     // v1.1
    timingStart: string | null;       // ISO time
    timingEnd: string | null;
    notes: string | null;
  };
  
  // Generation tracking
  generationPath: 'ai' | 'template' | 'manual' | null;
  clonedFrom: uuid | null;
  cloneAdaptations: CloneAdaptation[] | null;
  
  // Check Plan tracking
  checkPlanInvocations: number;
  firstCheckPlanAt: datetime | null;
  lastCheckPlanAt: datetime | null;
  checkPlanBeforeGate: boolean;
  
  // Transition tracking
  transitionAttempts: TransitionAttempt[];
  transitionedToConfirmingAt: datetime | null;
  planSnapshotIdAtConfirming: uuid | null;
  
  // Structure mode (post-transition)
  structureMode: 'editable' | 'locked' | 'change_requested';
  
  // Engagement signals
  blindAccept: boolean;
  madeAnyEditBeforeCheckPlan: boolean;
  manualAdditionsCount: number;
  
  // Readiness
  hostReadinessConfidence: 'high' | 'medium' | 'low' | null;
  
  // Revisions
  currentRevisionId: uuid;
  
  // Timestamps
  createdAt: datetime;
  updatedAt: datetime;
}

interface CloneAdaptation {
  field: string;
  originalValue: any;
  newValue: any;
  scalingApplied: boolean;
}

interface TransitionAttempt {
  attemptedAt: datetime;
  result: 'passed' | 'blocked';
  blockingReasons: string[];
}
```

### 3.2 Day

```typescript
interface Day {
  id: uuid;
  eventId: uuid;
  name: string;
  date: date;
  venue: string | null;  // overrides event venue if set
  startTime: string | null;  // ISO time
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'all_day' | null;
  isActive: boolean;  // false = travel day, skip in completeness checks
  displayOrder: number;
  
  createdAt: datetime;
  updatedAt: datetime;
}
```

### 3.3 Team

```typescript
interface Team {
  id: uuid;
  eventId: uuid;
  name: string;
  scope: string;  // description of what team covers
  domain: 'proteins' | 'vegetarian_mains' | 'sides' | 'salads' | 'starters' | 'desserts' | 'drinks' | 'later_food' | 'setup' | 'cleanup' | 'custom' | null;
  domainConfidence: 'high' | 'medium' | 'low';
  displayOrder: number;
  
  // Source tracking
  source: 'generated' | 'template' | 'manual';
  isProtected: boolean;  // survives regeneration
  
  createdAt: datetime;
  updatedAt: datetime;
}
```

### 3.4 Item

```typescript
interface Item {
  id: uuid;
  teamId: uuid;
  dayId: uuid | null;  // null = spans all days
  
  name: string;
  description: string | null;
  
  // Quantity (structured)
  quantityAmount: number | null;
  quantityUnit: 'kg' | 'g' | 'L' | 'ml' | 'count' | 'packs' | 'trays' | 'servings' | 'custom' | null;
  quantityUnitCustom: string | null;
  quantityText: string | null;  // fallback for edge cases
  quantityState: 'specified' | 'placeholder' | 'na';
  quantityLabel: 'calculated' | 'heuristic' | 'placeholder';
  quantitySource: 'host_inputs' | 'host_history' | 'host_defaults' | 'system_heuristics' | 'aggregate_patterns' | 'template';
  quantityDerivedFromTemplate: boolean;
  placeholderAcknowledged: boolean;
  quantityDeferredTo: 'coordinator' | null;
  
  // Critical
  critical: boolean;
  criticalReason: string | null;
  criticalSource: 'ai' | 'host' | 'rule';
  criticalOverride: 'none' | 'added' | 'removed';
  
  // Dietary tags
  dietaryTags: ('vegetarian' | 'vegan' | 'gluten_free' | 'dairy_free')[];
  
  // Equipment
  equipmentNeeds: string[];  // ['oven', 'stovetop', 'bbq', 'fridge']
  equipmentLoad: number;  // 0-1, fractional capacity
  durationMinutes: number | null;
  
  // Timing
  prepStartTime: string | null;  // ISO time
  prepEndTime: string | null;
  serveTime: string | null;
  dropOffAt: datetime | null;
  dropOffLocation: string | null;
  dropOffNote: string | null;
  
  // Source tracking
  source: 'generated' | 'template' | 'manual';
  isProtected: boolean;
  lastEditedBy: 'ai' | 'host' | null;
  
  createdAt: datetime;
  updatedAt: datetime;
}
```

### 3.5 Conflict

```typescript
interface Conflict {
  id: uuid;
  eventId: uuid;
  fingerprint: string;  // hash for deduplication
  
  type: 'timing' | 'dietary_gap' | 'structural_imbalance' | 'constraint_violation' | 'coverage_gap' | 'quantity_missing' | 'equipment_mismatch';
  severity: 'critical' | 'significant' | 'advisory';
  claimType: 'constraint' | 'risk' | 'pattern' | 'preference' | 'assumption';
  resolutionClass: 'fix_in_plan' | 'decision_required' | 'delegate_allowed' | 'informational';
  
  title: string;
  description: string;
  
  affectedItems: uuid[];
  affectedDays: uuid[];
  affectedParties: string[];  // human-readable: "6 vegetarian guests"
  
  // For timing conflicts
  equipment: string | null;
  timeSlot: string | null;
  capacityAvailable: number | null;
  capacityRequired: number | null;
  
  // For dietary gaps
  dietaryType: string | null;
  guestCount: number | null;
  category: string | null;
  currentCoverage: number | null;
  minimumNeeded: number | null;
  
  // AI suggestion
  suggestion: {
    action: string;
    proposedChanges: any[];
    reasoning: string;
  } | null;
  
  // Inputs for reset logic
  inputsReferenced: InputReference[];
  
  // Status
  status: 'open' | 'resolved' | 'dismissed' | 'acknowledged' | 'delegated';
  
  // Engagement tracking
  viewed: boolean;
  viewDuration: number;  // seconds
  whyThisViewed: boolean;
  dismissedWithoutReading: boolean;
  
  // Resolution
  resolvedBy: uuid | null;
  resolvedAt: datetime | null;
  dismissedAt: datetime | null;
  delegatedTo: 'coordinator' | null;
  delegatedAt: datetime | null;
  
  // For delegation
  canDelegate: boolean;
  delegateToRoles: string[];
  
  createdAt: datetime;
  updatedAt: datetime;
}

interface InputReference {
  type: 'event' | 'item' | 'team' | 'rule';
  id: uuid | null;
  field: string;
  valueAtDetection: any;
}
```

### 3.6 Acknowledgement

```typescript
interface Acknowledgement {
  id: uuid;
  conflictId: uuid;
  eventId: uuid;
  
  acknowledgedAt: datetime;
  acknowledgedBy: uuid;  // Host ID
  
  impactStatement: string;  // min 10 chars, must reference affected party or action
  impactUnderstood: boolean;
  mitigationPlanType: 'substitute' | 'reassign' | 'communicate' | 'accept_gap' | 'external_catering' | 'bring_own' | 'other';
  
  affectedParties: string[];  // system-generated
  alternativesConsidered: 'none' | 'reviewed' | 'attempted';
  
  // Visibility
  visibility: {
    cohosts: boolean;  // always true
    coordinators: 'relevant_only' | 'all' | 'none';
    participants: boolean;  // default false
  };
  
  // Supersession
  supersedesAcknowledgementId: uuid | null;
  status: 'active' | 'superseded';
  
  createdAt: datetime;
}
```

### 3.7 Plan Revision

```typescript
interface PlanRevision {
  id: uuid;
  eventId: uuid;
  revisionNumber: number;
  
  // Full snapshot
  teams: Team[];
  items: Item[];
  days: Day[];
  conflicts: Conflict[];
  acknowledgements: Acknowledgement[];
  
  createdAt: datetime;
  createdBy: uuid;
  reason: string | null;  // 'initial', 'regeneration', 'manual_save', 'pre_transition'
}
```

### 3.8 Plan Snapshot

```typescript
interface PlanSnapshot {
  id: uuid;
  eventId: uuid;
  phase: 'confirming';
  
  teams: Team[];
  items: Item[];
  days: Day[];
  criticalFlags: uuid[];  // item IDs
  acknowledgements: Acknowledgement[];
  
  createdAt: datetime;
}
```

### 3.9 Structure Change Request

```typescript
interface StructureChangeRequest {
  id: uuid;
  eventId: uuid;
  
  type: 'add_team' | 'rename_team' | 'remove_team' | 'move_item_team' | 'add_item_to_team' | 'remove_item' | 'change_critical_flag';
  
  requestedBy: uuid;
  requestedAt: datetime;
  reason: string;
  
  // Impact
  impactedCoordinators: uuid[];
  impactedItems: uuid[];
  deltaFromSnapshot: any;  // diff object
  
  status: 'pending' | 'applied' | 'cancelled';
  appliedAt: datetime | null;
  
  // For critical flag changes
  previousCriticalState: boolean | null;
  newCriticalState: boolean | null;
}
```

### 3.10 Structure Template

```typescript
interface StructureTemplate {
  id: uuid;
  hostId: uuid;
  templateSource: 'host' | 'gather_curated';
  
  name: string;
  occasionType: string;
  
  teams: {
    name: string;
    scope: string;
    domain: string | null;
    displayOrder: number;
  }[];
  
  items: {
    name: string;
    teamRef: string;  // team name
    dietaryTags: string[];
    equipmentNeeds: string[];
    suggestedCritical: boolean;
    dayRef: string | null;
  }[];
  
  days: {
    name: string;
    mealType: string | null;
  }[];
  
  // For Gather templates
  version: string | null;
  changelogSummary: string | null;
  publishedAt: datetime | null;
  
  createdFrom: uuid | null;  // eventId
  createdAt: datetime;
  updatedAt: datetime;
}
```

### 3.11 Quantities Profile

```typescript
interface QuantitiesProfile {
  id: uuid;
  hostId: uuid;
  occasionType: string;
  derivedFrom: uuid[];  // eventIds
  
  ratios: {
    proteinPerPerson: { amount: number; unit: string } | null;
    drinksPerPerson: { amount: number; unit: string } | null;
    dessertsPerPerson: { amount: number; unit: string } | null;
  };
  
  itemQuantities: {
    itemName: string;
    baseQuantity: { amount: number; unit: string };
    baseGuestCount: number;
    scalingRule: 'linear' | 'step' | 'fixed';
  }[];
  
  overrides: {
    itemName: string;
    rule: string;
  }[];
  
  createdAt: datetime;
  updatedAt: datetime;
}
```

### 3.12 Host Memory

```typescript
interface HostMemory {
  hostId: uuid;
  
  // Consent
  learningEnabled: boolean;
  aggregateContributionConsent: boolean;
  
  // Preferences
  preferences: {
    useHistoryByDefault: boolean;
  };
  
  // Derived patterns (separate collection)
  patterns: HostPattern[];
  
  // Defaults (explicit)
  defaults: HostDefault[];
  
  // Dismissed suggestions
  dismissedSuggestions: DismissedSuggestion[];
  
  updatedAt: datetime;
}

interface HostPattern {
  id: uuid;
  hostId: uuid;
  occasionType: string;
  patternType: 'team_structure' | 'domain_coverage' | 'quantity_ratio' | 'critical_items';
  patternData: any;
  derivedFrom: uuid[];  // eventIds
  confidence: 'high' | 'medium' | 'low';
  
  createdAt: datetime;
  updatedAt: datetime;
}

interface HostDefault {
  id: uuid;
  hostId: uuid;
  field: string;  // 'proteinPerPerson', 'defaultTeamCount', etc.
  value: any;
  setAt: datetime;
}

interface DismissedSuggestion {
  suggestionType: string;
  dismissedAt: datetime;
  count: number;
}
```

### 3.13 Deletion Receipt

```typescript
interface DeletionReceipt {
  id: uuid;
  hostId: uuid;
  deletedAt: datetime;
  scope: 'all' | 'events' | 'patterns' | 'specific_event';
  targetIds: uuid[];
  derivedArtifactsRemoved: boolean;
  aggregateContributionPurged: boolean;
}
```

---

## 4. API Endpoints

### 4.1 Event Management

```
POST   /api/events                     Create event
GET    /api/events/:id                 Get event
PATCH  /api/events/:id                 Update event parameters
DELETE /api/events/:id                 Delete event (draft only)

POST   /api/events/:id/save            Save pending changes (triggers hasPendingEdits: false)
```

### 4.2 Days

```
GET    /api/events/:id/days            List days
POST   /api/events/:id/days            Create day
PATCH  /api/events/:id/days/:dayId     Update day
DELETE /api/events/:id/days/:dayId     Delete day
```

### 4.3 Teams

```
GET    /api/events/:id/teams           List teams
POST   /api/events/:id/teams           Create team
PATCH  /api/events/:id/teams/:teamId   Update team
DELETE /api/events/:id/teams/:teamId   Delete team (must be empty or force)
```

### 4.4 Items

```
GET    /api/events/:id/items                     List all items
GET    /api/events/:id/teams/:teamId/items       List items in team
POST   /api/events/:id/teams/:teamId/items       Create item
PATCH  /api/events/:id/items/:itemId             Update item
DELETE /api/events/:id/items/:itemId             Delete item
POST   /api/events/:id/items/:itemId/move        Move item to different team
```

### 4.5 AI Integration

```
POST   /api/events/:id/generate        Generate plan from AI
POST   /api/events/:id/regenerate      Regenerate with modifier
POST   /api/events/:id/check           Run Check Plan assessment
GET    /api/events/:id/suggestions     Get pending suggestions
POST   /api/events/:id/suggestions/:suggestionId/accept    Accept suggestion
POST   /api/events/:id/suggestions/:suggestionId/dismiss   Dismiss suggestion
GET    /api/events/:id/suggestions/:suggestionId/explain   Get "Why this?" explanation
```

### 4.6 Conflicts

```
GET    /api/events/:id/conflicts                           List active conflicts
GET    /api/events/:id/conflicts/:conflictId               Get conflict details
POST   /api/events/:id/conflicts/:conflictId/resolve       Mark resolved
POST   /api/events/:id/conflicts/:conflictId/dismiss       Dismiss conflict
POST   /api/events/:id/conflicts/:conflictId/delegate      Delegate to coordinator
POST   /api/events/:id/conflicts/:conflictId/acknowledge   Acknowledge (Critical only)
GET    /api/events/:id/conflicts/dismissed                 List dismissed conflicts
```

### 4.7 Gate & Transition

```
POST   /api/events/:id/gate-check      Run gate check (returns pass/block)
POST   /api/events/:id/transition      Attempt transition to Confirming
```

### 4.8 Revisions

```
GET    /api/events/:id/revisions                   List revisions
GET    /api/events/:id/revisions/:revisionId       Get revision snapshot
POST   /api/events/:id/revisions/:revisionId/restore   Restore to revision
```

### 4.9 Structure Changes (post-transition)

```
POST   /api/events/:id/structure-changes           Request structure change
GET    /api/events/:id/structure-changes           List pending changes
POST   /api/events/:id/structure-changes/:id/apply Apply change
POST   /api/events/:id/structure-changes/:id/cancel Cancel change
```

### 4.10 Templates

```
GET    /api/templates                              List Host templates
GET    /api/templates/gather                       List Gather curated templates
POST   /api/templates                              Create template from event
GET    /api/templates/:id                          Get template
DELETE /api/templates/:id                          Delete template
POST   /api/templates/:id/clone                    Clone template to new event
```

### 4.11 Host Memory

```
GET    /api/memory                     Get Host memory summary
GET    /api/memory/events              List stored events
GET    /api/memory/patterns            List learned patterns
GET    /api/memory/defaults            List explicit defaults
DELETE /api/memory                     Delete all memory
DELETE /api/memory/patterns            Delete patterns only
DELETE /api/memory/events/:id          Delete specific event from memory
PATCH  /api/memory/settings            Update memory settings (learning, consent)
POST   /api/memory/export              Export all data
```

---

## 5. Gate Check Logic

### 5.1 Gate Blocking Reason Codes

| Code | Description | Condition |
|------|-------------|-----------|
| `CRITICAL_CONFLICT_UNACKNOWLEDGED` | Critical conflict without acknowledgement | `conflict.severity = 'critical' AND conflict.status NOT IN ('resolved', 'acknowledged')` |
| `CRITICAL_PLACEHOLDER_UNACKNOWLEDGED` | Critical item has placeholder quantity | `item.critical = true AND item.quantityState = 'placeholder' AND item.placeholderAcknowledged = false` |
| `STRUCTURAL_MINIMUM_TEAMS` | Zero teams | `COUNT(teams) = 0` |
| `STRUCTURAL_MINIMUM_ITEMS` | Zero items | `COUNT(items) = 0` |
| `UNSAVED_DRAFT_CHANGES` | Uncommitted edits | `event.hasPendingEdits = true` |

### 5.2 Gate Check Algorithm

```typescript
function gateCheck(event: Event): GateResult {
  // Check unsaved changes first
  if (event.hasPendingEdits) {
    return blocked('UNSAVED_DRAFT_CHANGES');
  }
  
  // Check structural minimums
  const teamCount = countTeams(event.id);
  if (teamCount === 0) {
    return blocked('STRUCTURAL_MINIMUM_TEAMS');
  }
  
  const itemCount = countItems(event.id);
  if (itemCount === 0) {
    return blocked('STRUCTURAL_MINIMUM_ITEMS');
  }
  
  // Check critical conflicts
  const criticalConflicts = getConflicts(event.id, { 
    severity: 'critical', 
    status: ['open'] 
  });
  
  for (const conflict of criticalConflicts) {
    return blocked('CRITICAL_CONFLICT_UNACKNOWLEDGED', conflict);
  }
  
  // Check critical items with placeholder quantities
  const criticalPlaceholders = getItems(event.id, {
    critical: true,
    quantityState: 'placeholder',
    placeholderAcknowledged: false
  });
  
  for (const item of criticalPlaceholders) {
    return blocked('CRITICAL_PLACEHOLDER_UNACKNOWLEDGED', item);
  }
  
  return passed();
}
```

### 5.3 Transition Process

```typescript
async function transition(event: Event): TransitionResult {
  // Run gate check
  const gateResult = gateCheck(event);
  
  if (gateResult.blocked) {
    recordTransitionAttempt(event.id, 'blocked', gateResult.reasons);
    return { success: false, blocks: gateResult.reasons };
  }
  
  // Create plan snapshot
  const snapshot = createPlanSnapshot(event);
  
  // Update event
  await updateEvent(event.id, {
    status: 'confirming',
    structureMode: 'locked',
    planSnapshotIdAtConfirming: snapshot.id,
    transitionedToConfirmingAt: now()
  });
  
  // Record successful attempt
  recordTransitionAttempt(event.id, 'passed', []);
  
  return { success: true, snapshotId: snapshot.id };
}
```

---

## 6. Conflict Detection

### 6.1 Timing Conflict Detection

```typescript
function detectTimingConflicts(event: Event): Conflict[] {
  const conflicts: Conflict[] = [];
  
  // Group items by day and equipment
  const itemsByDayEquipment = groupItems(event.id, ['dayId', 'equipmentNeeds']);
  
  for (const [key, items] of itemsByDayEquipment) {
    const { dayId, equipment } = parseKey(key);
    
    // Find overlapping time slots
    const timeSlots = groupByTimeSlot(items);
    
    for (const [slot, slotItems] of timeSlots) {
      const totalLoad = sum(slotItems.map(i => i.equipmentLoad));
      const capacity = getEquipmentCapacity(event, equipment);
      
      if (totalLoad > capacity) {
        conflicts.push({
          type: 'timing',
          severity: 'significant',
          claimType: 'constraint',
          resolutionClass: 'fix_in_plan',
          title: `Timing conflict: ${slotItems.length} ${equipment} items at ${slot}`,
          description: `Your venue has ${capacity} ${equipment}(s). These items can't all use it simultaneously.`,
          equipment,
          timeSlot: slot,
          capacityAvailable: capacity,
          capacityRequired: totalLoad,
          affectedItems: slotItems.map(i => i.id),
          affectedDays: [dayId],
          inputsReferenced: [
            { type: 'event', field: 'venue.ovenCount', valueAtDetection: capacity },
            ...slotItems.map(i => ({ type: 'item', id: i.id, field: 'serveTime', valueAtDetection: i.serveTime }))
          ],
          suggestion: generateStaggerSuggestion(slotItems, equipment)
        });
      }
    }
  }
  
  return conflicts;
}
```

### 6.2 Dietary Gap Detection

```typescript
function detectDietaryGaps(event: Event): Conflict[] {
  const conflicts: Conflict[] = [];
  
  if (event.dietaryStatus !== 'specified') {
    return conflicts;  // Can't detect gaps without specified dietary
  }
  
  const categories = ['mains', 'desserts', 'starters'];
  const dietaryTypes = ['vegetarian', 'vegan', 'glutenFree', 'dairyFree'];
  
  for (const category of categories) {
    for (const dietaryType of dietaryTypes) {
      const guestCount = event.dietary[dietaryType];
      
      if (guestCount > 0) {
        const coverage = countItemsWithDietaryTag(event.id, category, dietaryType);
        
        if (coverage === 0) {
          conflicts.push({
            type: 'dietary_gap',
            severity: 'critical',
            claimType: 'constraint',
            resolutionClass: 'decision_required',
            title: `No ${formatDietary(dietaryType)} ${category}`,
            description: `${guestCount} ${formatDietary(dietaryType)} guests will have no ${category} option.`,
            dietaryType,
            guestCount,
            category,
            currentCoverage: 0,
            minimumNeeded: 1,
            affectedParties: [`${guestCount} ${formatDietary(dietaryType)} guests`],
            inputsReferenced: [
              { type: 'event', field: `dietary.${dietaryType}`, valueAtDetection: guestCount }
            ],
            suggestion: {
              action: 'add_item',
              proposedItem: {
                name: `${formatDietary(dietaryType)} ${category.slice(0, -1)}`,
                teamRef: getCategoryTeam(category),
                dietaryTags: [dietaryType]
              }
            }
          });
        }
      }
    }
  }
  
  return conflicts;
}
```

### 6.3 Coverage Gap Detection

```typescript
function detectCoverageGaps(event: Event): Conflict[] {
  const conflicts: Conflict[] = [];
  
  const expectedDomains = getExpectedDomains(event.occasionType);
  const coveredDomains = getTeamDomains(event.id);
  
  for (const domain of expectedDomains) {
    if (!coveredDomains.includes(domain)) {
      conflicts.push({
        type: 'coverage_gap',
        severity: 'advisory',
        claimType: 'pattern',
        resolutionClass: 'informational',
        title: `No team covers ${formatDomain(domain)}`,
        description: `Based on domain mapping, no team appears to cover ${formatDomain(domain)}. This may be intentional.`,
        inputsReferenced: [
          { type: 'event', field: 'occasionType', valueAtDetection: event.occasionType }
        ]
      });
    }
  }
  
  return conflicts;
}
```

### 6.4 Conflict Fingerprinting

```typescript
function generateFingerprint(conflict: ConflictInput): string {
  const data = {
    type: conflict.type,
    affectedItems: conflict.affectedItems.sort(),
    affectedDays: conflict.affectedDays.sort(),
    inputsReferenced: conflict.inputsReferenced.map(i => `${i.type}:${i.id}:${i.field}:${i.valueAtDetection}`).sort()
  };
  
  return hash(JSON.stringify(data));
}
```

### 6.5 Dismissal Reset Logic

```typescript
function shouldResetDismissal(conflict: Conflict, currentEvent: Event): boolean {
  for (const input of conflict.inputsReferenced) {
    const currentValue = getCurrentValue(currentEvent, input);
    
    if (currentValue !== input.valueAtDetection) {
      return true;  // Input changed, reset dismissal
    }
  }
  
  return false;
}

function getCurrentValue(event: Event, input: InputReference): any {
  switch (input.type) {
    case 'event':
      return get(event, input.field);
    case 'item':
      const item = getItem(input.id);
      return get(item, input.field);
    case 'team':
      const team = getTeam(input.id);
      return get(team, input.field);
    default:
      return null;
  }
}
```

---

## 7. AI Integration Points

### 7.1 Generate Plan

**Endpoint:** `POST /api/events/:id/generate`

**Input:**
```typescript
{
  // Event parameters already stored on event object
}
```

**Process:**
1. Validate event has minimum parameters (guestCount touched, occasionType set)
2. Gather Host history if learningEnabled
3. Call AI with event parameters + Host patterns + system heuristics
4. AI returns draft structure (teams + items)
5. Store as pending draft (not committed to event)
6. Return draft for Host review

**AI Governance:** Plan AI Protocol applies. All outputs are drafts. Source and claim type labelled.

### 7.2 Regenerate

**Endpoint:** `POST /api/events/:id/regenerate`

**Input:**
```typescript
{
  modifier: string;  // "More vegetarian options", "Fewer teams", etc.
  preserveProtected: boolean;  // default true
}
```

**Process:**
1. Identify protected items/teams (`isProtected = true`)
2. Check for conflicts between modifier and protected items
3. If conflicts: return conflict for Host decision
4. Create revision snapshot (pre-regenerate)
5. Call AI with event parameters + modifier + protected items context
6. Generate diff preview
7. Return preview for Host confirmation
8. On confirm: apply changes, store revision

### 7.3 Check Plan

**Endpoint:** `POST /api/events/:id/check`

**Output:**
```typescript
{
  status: 'ready' | 'issues_found';
  conflicts: Conflict[];
  suggestions: Suggestion[];
  summary: {
    teamCount: number;
    itemCount: number;
    itemsWithQuantities: number;
    criticalItems: number;
    acknowledgedIssues: number;
  };
  readyToProceed: boolean;
}
```

**Process:**
1. Run all conflict detectors
2. Compare fingerprints to previous run
3. Reset dismissed conflicts if inputs changed
4. Generate suggestions for gaps
5. Calculate readiness

---

## 8. UI Specifications

### 8.1 Event Creation Flow

**Screen 1: Basic Info**
```
Create a new gathering
─────────────────────
Name: [________________________]
Occasion: [Christmas ▼]
Date(s): [Dec 24-26, 2025]

[Continue]
```

**Screen 2: Generation Path**
```
How would you like to build your plan?
──────────────────────────────────────
[Generate with AI]
  Fresh plan based on your event details

[Start from your history]
  Clone Christmas 2024 (48 guests, 8 teams)

[Use a Gather template]
  Start from a common pattern

[Build manually]
  Empty canvas
```

**Screen 3: Parameters (if AI or Template)**
```
Event details
─────────────
Guest count: [48] (±) Confidence: [High ▼]

Dietary requirements: [Specify ▼]
  Vegetarian: [6]
  Vegan: [0]
  Gluten-free: [3]
  Dairy-free: [2]
  Allergies: [2 nut allergies]

Venue: [Home - Kate's Kitchen]
  Kitchen access: [Full ▼]
  Ovens: [1]
  Timing: [No restrictions]
  Notes: [________________________]

[Generate Plan]
```

### 8.2 Draft Review

```
Review your plan
────────────────
Generated: 8 teams, 55 items, 6 critical

▼ Entrées & Nibbles (7 items)
  ☐ Cheese board (2 platters) — Heuristic
  ☐ Crackers (3 packs) — Heuristic
  ...

▼ Mains – Proteins (5 items)
  ⚠️ Roast lamb (7kg) — Calculated [Why this?]
  ☐ Glazed ham (4kg) — Calculated
  ...

[Accept & Edit]  [Regenerate...]
```

### 8.3 Plan Editor

```
Christmas 2025                                    [Check Plan]  [Move to Confirming]
───────────────────────────────────────────────────────────────────────────────────

Teams                          Items
─────                          ─────
▸ Entrées & Nibbles (7)        Roast lamb ⚠️
▸ Mains – Proteins (5)         7kg (Calculated) • Oven • 11:00am
▸ Mains – Vegetarian (2)       [Edit] [Move] [Delete]
▸ Vegetables & Sides (8)       
▸ Salads (3)                   Glazed ham
▸ Puddings (6)                 4kg (Calculated) • Oven • 10:30am
▸ Drinks (4)                   [Edit] [Move] [Delete]
▸ Later Food (3)               
                               + Add item
+ Add team
```

### 8.4 Check Plan Results

```
Plan Assessment
───────────────
✓ 8 teams, 52 items with quantities
⚠️ 2 issues need attention

CRITICAL
────────
⚠️ No vegetarian main
   6 vegetarian guests will have no main course option.
   [Add vegetarian main] [Acknowledge...]

SIGNIFICANT
───────────
⚠️ Timing conflict at 11:00am
   3 items need oven simultaneously. You have 1 oven.
   [Apply suggested stagger] [Edit times] [Dismiss]

ADVISORY
────────
ℹ️ Teams are unbalanced
   Mains has 12 items; Salads has 1.
   [Got it]

───────────────
Ready to proceed: No (1 critical issue remaining)
```

### 8.5 Acknowledgement Flow

```
Acknowledge: No vegetarian main
───────────────────────────────
Impact: 6 vegetarian guests will have no main course option.

How will you handle this?
[____________________________________________]
[____________________________________________]

Example: "Vegetarians will eat from sides and salads — confirmed with Sarah and Tom"

Mitigation type: [Communicate to guests ▼]

☐ I understand this means affected guests may have an incomplete meal

[Acknowledge and continue]  [Cancel]
```

### 8.6 Gate Block

```
Can't proceed yet
─────────────────
2 issues need attention:

⚠️ No vegetarian main (Critical)
   6 vegetarian guests will have no main course option.
   [Resolve] [Acknowledge]

⚠️ Pavlova quantity missing (Critical item)
   This is marked critical but has no quantity.
   [Enter quantity] [Defer to Coordinator]

[Cancel]
```

### 8.7 Transition Confirmation

```
Ready to invite Coordinators
────────────────────────────
Your plan has:
• 8 teams
• 52 items (48 with quantities, 4 deferred)
• 6 critical items marked
• 2 acknowledged issues

Coordinators will be able to:
• See all items in their team
• Assign items to participants
• Adjust quantities (within limits)

Once you proceed, the structure is locked.
You can still edit details, but teams and critical flags are fixed.

Does this structure give Coordinators what they need?

[Yes, proceed]  [Not yet, keep planning]
```

---

## 9. Revision & Undo System

### 9.1 Revision Triggers

| Trigger | Revision Reason |
|---------|-----------------|
| Event created | `initial` |
| Generate Plan accepted | `generation_accepted` |
| Regenerate confirmed | `regeneration` |
| Manual save | `manual_save` |
| Before transition | `pre_transition` |

### 9.2 Revision Storage

- Store last 5 revisions per event
- Each revision is a complete snapshot
- Older revisions archived (retrievable but not instant)

### 9.3 Restore Process

```typescript
async function restoreRevision(eventId: uuid, revisionId: uuid): Promise<void> {
  const revision = getRevision(revisionId);
  const currentRevision = createRevision(eventId, 'pre_restore');
  
  // Replace current state with revision state
  await deleteTeams(eventId);
  await deleteItems(eventId);
  await deleteDays(eventId);
  
  await createTeams(eventId, revision.teams);
  await createItems(eventId, revision.items);
  await createDays(eventId, revision.days);
  
  // Conflicts will be re-detected on next Check Plan
  await clearConflicts(eventId);
  
  await updateEvent(eventId, {
    currentRevisionId: revisionId
  });
}
```

---

## 10. Aggregate Contribution

### 10.1 K-Anonymity Rules

- Minimum k = 20 (configurable)
- All values bucketed before contribution
- Rare combinations suppressed

### 10.2 Bucketing Rules

| Field | Buckets |
|-------|---------|
| Guest count | 1-10, 11-20, 21-40, 41-60, 61-80, 81-100, 101+ |
| Team count | 1-3, 4-6, 7-9, 10+ |
| Venue type | home, hired, outdoor, mixed |
| Occasion type | as-is (enum) |

### 10.3 Contribution Process

```typescript
async function contributeToAggregate(event: Event): Promise<void> {
  if (!hostHasConsent(event.createdBy)) {
    return;  // No consent, no contribution
  }
  
  const pattern = extractPattern(event);
  const bucket = bucketPattern(pattern);
  
  const matchingHosts = countHostsInBucket(bucket);
  
  if (matchingHosts < K_ANONYMITY_THRESHOLD) {
    return;  // Too rare, suppress
  }
  
  await addToAggregate(bucket, pattern);
}
```

---

## 11. Testing Requirements

### 11.1 Unit Tests

| Area | Tests Required |
|------|----------------|
| Gate check | All 5 blocking codes; edge cases |
| Conflict detection | Each conflict type; fingerprinting; reset logic |
| Quantity handling | All states; scaling; template derivation |
| Acknowledgement | Validation; supersession; visibility |
| Revision | Create; restore; diff |

### 11.2 Integration Tests

| Flow | Tests Required |
|------|----------------|
| Event creation → Generation → Transition | Happy path |
| Clone → Adapt → Check → Transition | With scaling |
| Manual build → Check Plan → Resolve → Transition | Without AI |
| Regenerate with protected items | Preservation; conflicts |
| Post-transition structure change | Request; notification; apply |

### 11.3 QA Scenarios

Reference: Plan AI Protocol Test Cases document for full QA checklist.

---

## 12. Implementation Phases

### Phase 1: Foundation (Week 1-2)

- [ ] Data model (all entities)
- [ ] Event CRUD
- [ ] Day/Team/Item CRUD
- [ ] Basic UI shell

### Phase 2: AI Integration (Week 3-4)

- [ ] Generate Plan endpoint
- [ ] Regenerate with preview
- [ ] Check Plan endpoint
- [ ] Suggestion accept/dismiss

### Phase 3: Conflict System (Week 5-6)

- [ ] Conflict detection (all types)
- [ ] Fingerprinting + reset logic
- [ ] Acknowledgement flow
- [ ] Conflict UI

### Phase 4: Gate & Transition (Week 7)

- [ ] Gate check logic
- [ ] Transition flow
- [ ] Plan snapshot
- [ ] Post-transition structure mode

### Phase 5: Templates & Memory (Week 8-9)

- [ ] Structure templates
- [ ] Quantities profiles
- [ ] Host memory system
- [ ] Clone workflow

### Phase 6: Refinement (Week 10)

- [ ] Revision system
- [ ] Divergence surfacing
- [ ] Fossilisation detection
- [ ] Edge case handling

### Phase 7: Testing & Polish (Week 11-12)

- [ ] Full test suite
- [ ] QA scenarios
- [ ] Performance optimization
- [ ] Documentation

---

## 13. Success Criteria

### Functional

- [ ] Host can create event and generate plan in < 5 minutes
- [ ] Check Plan surfaces real conflicts with actionable suggestions
- [ ] Gate blocks only on documented reason codes
- [ ] Transition creates valid snapshot
- [ ] Post-transition changes are controlled and notified

### Performance

- [ ] Generate Plan returns in < 10 seconds
- [ ] Check Plan returns in < 3 seconds
- [ ] UI interactions < 200ms response

### Reliability

- [ ] No data loss on regeneration (protected items preserved)
- [ ] Revision restore works correctly
- [ ] Conflict fingerprints are stable

### Privacy

- [ ] Host memory scoped correctly
- [ ] Aggregate contribution respects consent
- [ ] K-anonymity enforced
- [ ] Deletion is complete

---

## 14. Open Questions

| Question | Owner | Status |
|----------|-------|--------|
| Stovetop/BBQ in v1 or v1.1? | Product | v1.1 |
| Coordinator notification mechanism | Engineering | TBD |
| AI model selection | AI Team | TBD |
| Mobile-first or responsive? | Design | TBD |

---

## Appendix A: Enums

```typescript
type OccasionType = 'christmas' | 'thanksgiving' | 'easter' | 'wedding' | 'birthday' | 'reunion' | 'retreat' | 'other';

type EventStatus = 'draft' | 'confirming' | 'frozen' | 'live' | 'completed';

type DietaryStatus = 'unspecified' | 'none' | 'specified';

type VenueType = 'home' | 'hired_venue' | 'outdoor' | 'mixed' | 'other';

type KitchenAccess = 'full' | 'limited' | 'none' | 'catering_only';

type GuestCountConfidence = 'high' | 'medium' | 'low';

type GenerationPath = 'ai' | 'template' | 'manual';

type ItemSource = 'generated' | 'template' | 'manual';

type QuantityState = 'specified' | 'placeholder' | 'na';

type QuantityLabel = 'calculated' | 'heuristic' | 'placeholder';

type QuantitySource = 'host_inputs' | 'host_history' | 'host_defaults' | 'system_heuristics' | 'aggregate_patterns' | 'template';

type CriticalSource = 'ai' | 'host' | 'rule';

type Domain = 'proteins' | 'vegetarian_mains' | 'sides' | 'salads' | 'starters' | 'desserts' | 'drinks' | 'later_food' | 'setup' | 'cleanup' | 'custom';

type ConflictType = 'timing' | 'dietary_gap' | 'structural_imbalance' | 'constraint_violation' | 'coverage_gap' | 'quantity_missing' | 'equipment_mismatch';

type ConflictSeverity = 'critical' | 'significant' | 'advisory';

type ClaimType = 'constraint' | 'risk' | 'pattern' | 'preference' | 'assumption';

type ResolutionClass = 'fix_in_plan' | 'decision_required' | 'delegate_allowed' | 'informational';

type ConflictStatus = 'open' | 'resolved' | 'dismissed' | 'acknowledged' | 'delegated';

type MitigationPlanType = 'substitute' | 'reassign' | 'communicate' | 'accept_gap' | 'external_catering' | 'bring_own' | 'other';

type StructureMode = 'editable' | 'locked' | 'change_requested';

type StructureChangeType = 'add_team' | 'rename_team' | 'remove_team' | 'move_item_team' | 'add_item_to_team' | 'remove_item' | 'change_critical_flag';

type GateBlockingCode = 'CRITICAL_CONFLICT_UNACKNOWLEDGED' | 'CRITICAL_PLACEHOLDER_UNACKNOWLEDGED' | 'STRUCTURAL_MINIMUM_TEAMS' | 'STRUCTURAL_MINIMUM_ITEMS' | 'UNSAVED_DRAFT_CHANGES';
```

---

## Appendix B: File Structure

```
/gather
├── prisma/
│   ├── schema.prisma
│   └── seed.ts
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── events/
│   │   │   ├── templates/
│   │   │   ├── memory/
│   │   │   └── ...
│   │   ├── plan/
│   │   │   ├── [eventId]/
│   │   │   │   ├── page.tsx
│   │   │   │   ├── edit/
│   │   │   │   ├── check/
│   │   │   │   └── transition/
│   │   │   └── new/
│   │   └── ...
│   ├── lib/
│   │   ├── ai/
│   │   │   ├── generate.ts
│   │   │   ├── regenerate.ts
│   │   │   ├── check.ts
│   │   │   └── governance.ts  // Plan AI Protocol rules
│   │   ├── conflicts/
│   │   │   ├── detect.ts
│   │   │   ├── timing.ts
│   │   │   ├── dietary.ts
│   │   │   ├── coverage.ts
│   │   │   └── fingerprint.ts
│   │   ├── gate/
│   │   │   ├── check.ts
│   │   │   └── transition.ts
│   │   ├── memory/
│   │   │   ├── host.ts
│   │   │   ├── patterns.ts
│   │   │   └── aggregate.ts
│   │   ├── revisions/
│   │   │   ├── create.ts
│   │   │   └── restore.ts
│   │   └── templates/
│   │       ├── structure.ts
│   │       └── quantities.ts
│   ├── components/
│   │   ├── plan/
│   │   │   ├── EventForm.tsx
│   │   │   ├── TeamList.tsx
│   │   │   ├── ItemCard.tsx
│   │   │   ├── ConflictCard.tsx
│   │   │   ├── AcknowledgeModal.tsx
│   │   │   ├── CheckPlanResults.tsx
│   │   │   ├── TransitionConfirm.tsx
│   │   │   └── ...
│   │   └── ...
│   └── types/
│       ├── event.ts
│       ├── conflict.ts
│       ├── template.ts
│       └── ...
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
└── docs/
    ├── plan-protocol.md
    ├── plan-ai-protocol.md
    ├── plan-build-spec.md
    └── plan-test-cases.md
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | January 2025 | Initial spec from walked protocols |
