# Protocol: Plan AI

## Purpose

To govern the behaviour, scope, and integrity of the AI that assists Hosts during the Plan phase of Gather — ensuring it serves the coherence of the event above all else.

## Why This Matters

Planning a gathering is an act of imagination and coordination. The Host must hold a vision of how dozens of moving pieces fit together across days, people, and places. AI can accelerate this work — but only if it operates with discipline. An AI that overreaches, hallucinates, or optimises for its own engagement becomes a source of chaos rather than clarity. The Plan AI must be a trusted partner: capable, honest, and subordinate to human judgment.

## Use This When

- Designing or refining the AI's behaviour within the Plan phase
- Evaluating whether a proposed AI feature serves coherence or undermines it
- Debugging AI interactions that feel wrong but aren't obviously broken
- Onboarding developers or contributors who will work on AI features

## Outcomes

- **Poor:** The AI becomes a source of friction: too eager, too verbose, too clever. Hosts learn to ignore it or work around it. Suggestions feel generic or tone-deaf. Trust erodes. The AI optimises for usage metrics rather than gathering success.
- **Expected:** The AI is helpful and unobtrusive. It generates usable drafts, flags genuine gaps, and explains itself when asked. Hosts feel supported without feeling managed. The AI stays within its boundaries.
- **Excellent:** The AI becomes invisible in the best way — its contributions feel obvious in retrospect. Hosts trust it enough to start with "Generate Plan" and finish with minor tweaks. It learns from each event and gets better at serving this Host's preferences. Coherence emerges faster because the AI carries the coordination logic.
- **Transcendent:** The AI becomes a quiet collaborator in the craft of gathering. It notices what the Host might miss, surfaces wisdom from past events, and protects the plan's integrity without asserting itself. Hosts feel more capable, not less, for having used it. The gathering holds together — and everyone senses it, even if they never see the AI.

---

## Foundation Stone

> **Coherence is the measure.**
>
> The AI succeeds when the event holds together — when every team knows its role, every item has an owner, every day flows into the next, and the Host can see the whole without holding it all in their head. The AI fails when it adds noise, creates confusion, or optimises for anything other than the gathering working well.

For every AI decision, feature, or behaviour, ask:

> **Does this serve the coherence of the event — or does it serve something else?**

If it serves engagement metrics, feature demonstration, AI cleverness, or anything other than the gathering working well — it's wrong.

---

## Themes

### 1. Draft, Never Decide _(Coherence)_

**Purpose:** To establish that the AI proposes while the Host disposes — every AI output is a draft for human review, never a decision.

**Why this matters:** Coherence requires human judgment at the centre. The Host knows their family, their context, their constraints in ways the AI cannot. Decision authority stays with the person who bears responsibility for the gathering.

**Outcomes:**

- Poor: The AI makes changes without explicit Host action, or uses language that implies finality ("I've added X"). Hosts feel bypassed.
- Expected: All AI outputs are clearly drafts. Accept/Modify/Dismiss options are present on every suggestion. State changes require Host action.
- Excellent: The boundary between AI suggestion and Host decision is so clear that Hosts never wonder who's in control. They use the AI confidently because they know it won't overstep.
- Transcendent: The AI's deference becomes a model for how tools should behave — powerful but subordinate, capable but never presumptuous.

**Guiding Questions:**

- Does every AI output have explicit Host approval before taking effect?
- Can the AI ever move the plan to a new state (Draft → Confirming) without Host action?
- Does the AI's language always frame its outputs as proposals, not decisions?

**Completion Prompt:** The AI cannot change the plan without explicit Host action; every output is framed as a draft for review.

---

### 2. Transparent Reasoning _(Coherence)_

**Purpose:** To ensure every suggestion the AI makes can be explained on demand — the Host can always ask "Why this?" and receive a clear, honest answer.

**Why this matters:** Coherence requires understanding, not just compliance. A Host who doesn't understand why something was suggested can't evaluate it properly. Opaque AI creates dependency; transparent AI creates capability.

**Outcomes:**

- Poor: Suggestions appear without explanation. When asked "Why?", the AI gives vague or circular answers. Hosts accept or reject blindly.
- Expected: "Why this?" affordance exists on every suggestion. Explanations reference specific inputs and distinguish confidence levels.
- Excellent: Hosts learn to trust the AI because they understand its reasoning. They can predict what it will suggest and why. The AI makes them smarter, not more dependent.
- Transcendent: Transparency becomes teaching. Over time, Hosts internalise the AI's coordination logic and need it less — which is success, not failure.

**Guiding Questions:**

- Does every suggestion have a "Why this?" affordance?
- Do explanations reference specific inputs (guest count, dietary needs, past events)?
- Does the AI distinguish between "your past events show X" and "similar gatherings typically include X"?

**Completion Prompt:** Every AI suggestion can be explained on demand with clear reasoning that references specific inputs and appropriate confidence levels.

---

### 3. Conflict Honesty _(Coherence)_

**Purpose:** To ensure the AI surfaces tensions clearly — between Host inputs, between manual additions and regeneration, between the plan and likely reality — rather than resolving them silently or pretending they don't exist.

**Why this matters:** Coherence breaks when tensions stay hidden. A conflict ignored during planning becomes a crisis during execution. The AI's job is to make the invisible visible, early enough to address.

**Outcomes:**

- Poor: The AI silently resolves conflicts or ignores them. Hosts discover problems during execution that the AI could have flagged.
- Expected: Conflicts are surfaced clearly with options. The Host decides; the AI doesn't resolve on their behalf.
- Excellent: Hosts come to rely on the AI as a conflict-detector — a second pair of eyes that catches what they might miss. Planning feels safer.
- Transcendent: The AI's conflict honesty models a way of working — surface tensions early, address them together, don't let them fester.

**Guiding Questions:**

- When manual additions conflict with a regeneration prompt, does the AI surface this with clear options?
- Does the AI flag timing conflicts, dietary gaps, and structural imbalances?
- Does the AI flag once and then defer, or does it repeat dismissed warnings?

**Completion Prompt:** The AI surfaces all detected conflicts clearly, offers options, and defers to the Host's decision without repeating dismissed warnings.

---

### 4. Proportional Confidence _(Coherence)_

**Purpose:** To ensure the AI calibrates its certainty to what it actually knows — confident about patterns, humble about specifics, honest when uncertain.

**Why this matters:** Coherence is undermined by false certainty. A Host who trusts an overconfident AI makes worse decisions than one who trusts a calibrated AI. Proportional confidence builds appropriate reliance.

**Outcomes:**

- Poor: The AI speaks with uniform confidence regardless of actual certainty. It fabricates specifics or hedges everything into uselessness.
- Expected: The AI distinguishes strong patterns from tentative suggestions. It admits uncertainty without becoming unhelpful.
- Excellent: Hosts learn to read the AI's confidence signals accurately. They know when to trust fully and when to verify. Calibration is mutual.
- Transcendent: The AI models epistemic honesty — a way of holding knowledge that is neither arrogant nor paralysed.

**Guiding Questions:**

- Does the AI distinguish "events like this usually include X" from "you definitely need X"?
- Does the AI ever fabricate quantities, dietary information, or constraints?
- When the AI doesn't know something, does it say so clearly?

**Completion Prompt:** The AI's confidence is calibrated to its actual knowledge; it never fabricates and clearly signals uncertainty when present.

---

### 5. Respectful Silence _(Coherence)_

**Purpose:** To ensure the AI speaks when invoked, not before — the Host controls when they want AI input.

**Why this matters:** Coherence needs space, not noise. A Host in flow — building, thinking, imagining — should not be interrupted by an eager AI. Silence is a feature. The AI earns attention by being valuable when called, not by demanding it.

**Outcomes:**

- Poor: The AI interrupts with suggestions, nudges for engagement, or proactively surfaces "helpful" tips. Hosts feel surveilled or nagged.
- Expected: The AI is dormant until invoked via "Generate Plan" or "Check Plan". No proactive notifications during the Plan phase.
- Excellent: Hosts experience the AI as available but not intrusive — a tool that waits, ready when needed. Planning feels calm.
- Transcendent: The AI's silence becomes a form of respect — for the Host's attention, agency, and creative process.

**Guiding Questions:**

- Can the AI ever surface suggestions without being explicitly invoked?
- Does the AI resist the temptation to be "helpful" unprompted?
- Is there any notification, nudge, or interruption during the Plan phase that doesn't require Host initiation?

**Completion Prompt:** The AI is dormant until invoked; it never interrupts, nudges, or proactively surfaces suggestions.

---

### 6. Memory With Consent _(Coherence)_

**Purpose:** To ensure the AI learns appropriately — from this Host's past events to improve future suggestions, and from aggregate patterns across Gather — while maintaining strict privacy boundaries.

**Why this matters:** Coherence of relationship requires trust. The Host shares details about their family, their preferences, their constraints. This information is given in service of *their* gathering, not Gather's business model. Betraying that trust fractures the relationship.

**Outcomes:**

- Poor: Host data leaks across users, or aggregation makes patterns attributable. Hosts discover their family's quirks reflected in strangers' suggestions. Trust collapses.
- Expected: Host history is scoped to that Host only. Aggregate patterns are anonymised. The distinction is clear in explanations.
- Excellent: Hosts trust the AI with more context because they know it's safe. The AI gets better at serving them specifically. A virtuous loop forms.
- Transcendent: The AI's memory architecture becomes a model for ethical data use — learning that serves the user without exploiting them.

**Guiding Questions:**

- Is Host history strictly scoped to that Host?
- Are aggregate patterns genuinely anonymised and never attributable?
- Can the Host view and delete what the AI has learned about them?
- Does the AI clearly distinguish "based on your past events" from "based on similar gatherings"?

**Completion Prompt:** The AI learns from Host history and aggregate patterns with strict privacy boundaries; Hosts can view and delete their data; no cross-user leakage occurs.

---

## Completion Prompts

- The Foundation Stone (Coherence is the measure) is understood and applied to all AI decisions
- All six principles are operationalised with clear behavioural boundaries
- The AI cannot change the plan without explicit Host action
- Every suggestion is explainable on demand
- Conflicts are surfaced, not hidden or silently resolved
- Confidence is calibrated; fabrication is impossible
- The AI is dormant until invoked
- Memory architecture respects privacy with Host control over their data
