# Protocol: Plan

## Purpose

To govern the Plan phase of Gather — the phase where a Host (or two Hosts working together) constructs the complete coordination structure for a gathering before anyone else is invited.

## Why This Matters

A gathering succeeds or fails based on the quality of its plan. But "quality" isn't complexity — it's clarity. A good plan answers every coordination question before it's asked: who's responsible, what's needed, when it happens, where things go. The Plan phase is where that clarity is built. If this phase is rushed, chaotic, or incomplete, every downstream phase inherits the confusion.

## Use This When

- A Host is creating a new event in Gather
- Refining or reviewing the Plan phase workflow
- Debugging why a gathering's coordination broke down
- Onboarding Hosts to understand what "planning" means in Gather
- Evaluating whether a feature belongs in Plan phase or a later phase

---

## Outcomes

- **Poor:** The Host creates a partial structure — teams without items, items without quantities, critical gaps unmarked. The plan moves forward with hidden fragility. Coordinators inherit confusion; participants inherit ambiguity. The gathering feels chaotic.

- **Expected:** The Host creates a complete structure with all teams, items, quantities, and critical flags defined. Gaps are identified before moving forward. The plan is stable enough that Coordinators can do their work without re-architecting.

- **Excellent:** The Host creates a plan that feels inevitable — the structure matches the gathering's reality so well that Coordinators and Participants experience it as obvious. The AI accelerates this without distorting it. The Host finishes planning feeling clear, not exhausted.

- **Transcendent:** The Plan becomes a reusable pattern. Next year's gathering starts from this year's learning. The Host's craft of gathering improves over time, supported by memory and structure. Planning becomes a calm ritual, not a burden.

---

## Boundaries

### What Plan Phase Includes

- Event creation (name, occasion, dates, venue)
- Guest parameters (count, dietary requirements, constraints)
- Team structure (which teams, what scope each covers)
- Item definition (what's needed, quantities, timing, critical flags)
- AI-assisted generation and assessment
- Conflict detection and resolution
- Structure refinement until ready

### What Plan Phase Excludes

- Coordinator assignment (happens at transition to Confirming)
- Participant invitations (happens after Confirming)
- Item assignments to people (Confirming phase)
- Execution tracking (Live phase)
- Recipes, budgets, shopping lists (out of scope for Gather)

### The Boundary Test

If an action requires knowing *who* will do something, it belongs in Confirming or later.
If an action defines *what* needs doing, it belongs in Plan.

---

## Roles

### Host

The person (or pair) responsible for the gathering's coherence. In Plan phase, the Host:

- Creates the event and defines its parameters
- Builds or generates the team and item structure
- Reviews AI suggestions and decides what to accept
- Resolves conflicts and acknowledges critical issues
- Decides when the plan is ready to move forward

### Co-Host (optional)

A second Host with equal authority. Both can:

- Edit any part of the plan
- Generate, regenerate, and check plan
- Accept or dismiss suggestions
- Move the plan to Confirming

Co-Host exists for gatherings where responsibility is genuinely shared (e.g., couples planning together). It is not for delegation — that's what Coordinators are for.

### AI

The planning assistant, governed by the Plan AI Protocol. In Plan phase, the AI:

- Generates draft plans from Host inputs
- Regenerates with modifiers when asked
- Assesses completeness and surfaces conflicts when invoked
- Explains its reasoning when asked
- Remains silent unless invoked

The AI is a tool, not a participant. It has no authority to change the plan.

---

## Workflow

### Phase Overview

```
┌─────────────────────────────────────────────────────────────┐
│                      PLAN PHASE                             │
│                                                             │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐              │
│  │  Create  │───▶│  Build   │───▶│  Refine  │───▶ Gate ───▶│ Confirming
│  │  Event   │    │  Draft   │    │  Until   │     Check    │
│  └──────────┘    └──────────┘    │  Ready   │              │
│                        ▲         └────┬─────┘              │
│                        │              │                    │
│                        └──────────────┘                    │
│                         (iterate)                          │
└─────────────────────────────────────────────────────────────┘
```

### Step 1: Create Event

**What happens:**
Host creates a new event with basic parameters.

**Required inputs:**
- Event name
- Occasion type (Christmas, reunion, retreat, wedding, other)
- Date(s) — single day or multi-day with named days
- Venue (name, location, known constraints)

**Optional inputs:**
- Guest count (can be estimated, refined later)
- Dietary requirements (can be added later)
- Notes or special considerations

**Completion:**
Event exists in Draft status. No structure yet.

---

### Step 2: Build Draft

**What happens:**
Host constructs the team and item structure — either manually, via AI generation, or a combination.

**Path A: AI Generation**

1. Host adds details:
   - Guest count (required for generation)
   - Dietary requirements
   - Venue constraints (equipment, timing)
   - Any specifics ("We always do a Boxing Day BBQ")

2. Host clicks **Generate Plan**

3. AI produces complete draft:
   - Teams with scope definitions
   - Items with quantities, timing, critical flags
   - All quantities labelled (Calculated/Heuristic/Placeholder)
   - Assumptions visible where inputs were missing

4. Host reviews draft:
   - Accept as starting point, or
   - **Regenerate** with modifier ("More vegetarian options", "Fewer teams")

**Path B: Manual Build**

1. Host creates teams manually
2. Host adds items to each team
3. Host sets quantities, timing, critical flags
4. No AI involved unless Host invokes it later

**Path C: Hybrid**

1. Host generates draft via AI
2. Host adds manual teams/items (tagged `source: manual`)
3. If Host regenerates later:
   - Option to keep manual additions or replace all
   - Conflicts between manual items and regeneration prompt are surfaced

**Completion:**
Draft structure exists — teams and items defined.

---

### Step 3: Refine Until Ready

**What happens:**
Host iterates on the structure until satisfied. This may involve multiple cycles.

**Available actions:**

| Action | What it does |
|--------|--------------|
| Edit item | Change name, quantity, timing, flags |
| Add item | Create new item in a team |
| Delete item | Remove item from plan |
| Move item | Reassign item to different team |
| Edit team | Change name, scope, merge teams |
| Add team | Create new team |
| Delete team | Remove team (items must be moved or deleted first) |
| **Check Plan** | Invoke AI assessment |
| **Regenerate** | Request new AI draft (with options for manual additions) |

**Check Plan (AI Assessment):**

When invoked, AI scans current structure and returns:

- Completeness status
- Conflicts by severity (Critical / Significant / Advisory)
- Suggestions with source, claim type, and confidence
- "Ready to proceed" indicator if no Critical conflicts

Host can:
- Accept suggestions (applies them as edits)
- Dismiss suggestions (AI goes silent on that issue unless inputs change)
- Acknowledge Critical conflicts (required before transition)

**Iteration continues until:**
- Host is satisfied with structure
- All Critical conflicts are resolved or acknowledged
- Host decides to move forward

---

### Step 4: Gate Check and Transition

**What happens:**
Host attempts to move from Draft to Confirming. System performs gate check.

**Gate check evaluates:**

1. **Critical conflicts** — any unacknowledged?
   - If yes: Block transition, surface conflicts, require acknowledgement
   - If no: Proceed

2. **Structural minimums** — does the plan have substance?
   - At least one team
   - At least one item
   - (Not enforced: item assignments — that's Confirming phase)

**If gate passes:**
- Plan status changes to Confirming
- Structure is locked from major changes (teams, critical flags)
- Minor edits still possible (quantities, descriptions)
- Coordinators can now be assigned and invited

**If gate blocks:**
- Host sees specific Critical conflicts
- Must acknowledge each or resolve
- Can then retry transition

---

## Data Model (Plan Phase Relevant)

### Event

| Field | Type | Notes |
|-------|------|-------|
| id | UUID | |
| name | string | Required |
| occasionType | enum | christmas, reunion, retreat, wedding, other |
| status | enum | draft, confirming, frozen, live, completed |
| createdBy | Host ID | |
| coHost | Host ID | Optional |

### Day

| Field | Type | Notes |
|-------|------|-------|
| id | UUID | |
| eventId | UUID | |
| name | string | "Christmas Eve", "Day 1", etc. |
| date | date | |
| startTime | time | Optional |
| venue | string | Optional (can differ from event venue) |

### Team

| Field | Type | Notes |
|-------|------|-------|
| id | UUID | |
| eventId | UUID | |
| name | string | "Mains", "Puddings", etc. |
| scope | string | Description of what this team covers |
| displayOrder | int | |

### Item

| Field | Type | Notes |
|-------|------|-------|
| id | UUID | |
| teamId | UUID | |
| dayId | UUID | Optional (some items span days) |
| name | string | |
| quantity | string | Freeform ("7kg", "48 servings", "2 bottles") |
| quantityLabel | enum | calculated, heuristic, placeholder |
| quantitySource | enum | host_inputs, host_history, host_defaults, system_heuristics, aggregate_patterns |
| critical | boolean | Blocks freeze if unassigned |
| dietary | flags | glutenFree, dairyFree, vegetarian, vegan |
| dropOffAt | datetime | Optional |
| dropOffLocation | string | Optional |
| notes | string | Optional |
| source | enum | generated, manual |

### Conflict

| Field | Type | Notes |
|-------|------|-------|
| id | UUID | |
| eventId | UUID | |
| type | enum | timing, dietary_gap, structural_imbalance, constraint_violation, etc. |
| severity | enum | critical, significant, advisory |
| claimType | enum | constraint, risk, pattern, preference, assumption |
| description | string | Human-readable |
| affectedItems | UUID[] | |
| status | enum | open, dismissed, acknowledged |
| dismissedAt | datetime | |
| acknowledgedAt | datetime | |
| acknowledgedText | string | Host's acknowledgement (Critical only) |
| inputSnapshot | JSON | Input values at time of detection (for reset logic) |

---

## Templates

### What Templates Are

A template is a saved plan structure that can be cloned for future events. Templates enable:

- "Clone last year's Christmas" as a starting point
- Gather-provided templates for common occasion types
- Host-created templates for recurring gatherings

### Template Contents

A template includes:
- Team structure (names, scopes)
- Item structure (names, relative quantities, critical flags, dietary tags)
- Day structure (for multi-day templates)

A template does NOT include:
- Specific dates
- Specific guest counts
- Assignments
- Venue details

### Template Workflow

**Creating a template:**
1. Host completes an event
2. Host clicks "Save as Template"
3. Template saved to Host's library

**Using a template:**
1. Host creates new event
2. Host selects "Start from template"
3. Structure cloned into Draft
4. Host adjusts for this event's specifics (dates, guest count, etc.)
5. AI can assess and suggest adjustments: "Guest count changed from 48 to 30 — consider scaling quantities"

**Gather-provided templates:**
- Available for common occasions (Christmas, Thanksgiving, Wedding Reception, etc.)
- Serve as starting points for new Hosts
- Labelled as `source: template` (not `host_history`)

---

## AI Integration

The Plan phase integrates with AI through three invocation points:

### 1. Generate Plan

**Trigger:** Host clicks "Generate Plan"
**Input:** Event details, guest parameters, dietary requirements, venue constraints, Host notes
**Output:** Complete draft plan with teams, items, quantities, flags
**Governance:** Plan AI Protocol

### 2. Regenerate

**Trigger:** Host clicks "Regenerate" with optional modifier
**Input:** Original inputs + modifier prompt + current manual additions
**Output:** New draft plan, with options for handling manual additions
**Governance:** Plan AI Protocol (especially conflict honesty for manual additions)

### 3. Check Plan

**Trigger:** Host clicks "Check Plan"
**Input:** Current plan state
**Output:** Assessment with conflicts, suggestions, completeness status
**Governance:** Plan AI Protocol (especially transparent reasoning, proportional confidence)

### AI Boundaries in Plan Phase

- AI cannot edit the plan without Host acceptance
- AI cannot invoke itself
- AI cannot surface suggestions outside these three invocation points
- AI reasoning follows the Plan AI Protocol's epistemic standards

---

## Completion Prompts

- [ ] Event created with occasion, dates, and venue defined
- [ ] Guest parameters entered (count, dietary requirements)
- [ ] Team structure complete (all responsibility domains covered)
- [ ] Items defined with quantities, timing, and critical flags
- [ ] Quantities labelled and sourced (no unexamined placeholders)
- [ ] Check Plan run at least once
- [ ] All Critical conflicts resolved or explicitly acknowledged
- [ ] Host confident that Coordinators can work from this structure
- [ ] Plan transitioned to Confirming

---

## Failure Modes

### Premature Transition

**Symptom:** Plan moves to Confirming with unexamined gaps
**Cause:** Host skipped Check Plan or dismissed without reading
**Prevention:** Gate check requires acknowledgement for Critical conflicts; UI shows Check Plan affordance clearly

### Over-Engineering

**Symptom:** Plan has 15 teams for a 20-person gathering
**Cause:** Host (or AI) created structure that exceeds the gathering's needs
**Prevention:** AI should flag structural imbalance; system heuristics suggest appropriate scale; Host education

### AI Over-Reliance

**Symptom:** Host accepts all AI suggestions without review; plan doesn't match their actual gathering
**Cause:** "Generate and done" workflow without refinement
**Prevention:** AI outputs are clearly labelled as drafts; Check Plan surfaces mismatches; quantities show their basis

### Manual Chaos

**Symptom:** Host builds entirely manually, misses obvious gaps
**Cause:** Host never invokes AI, doesn't know what they don't know
**Prevention:** Check Plan affordance visible; first-time Host nudge (one-time, not nagging) to try Check Plan before transition

### Template Fossilisation

**Symptom:** Host clones last year's plan without adapting to changed circumstances
**Cause:** Memory serves habit, not coherence
**Prevention:** AI surfaces divergence when inputs change significantly; templates are starting points, not prescriptions

---

## Relationship to Other Protocols

| Protocol | Relationship |
|----------|--------------|
| **Plan AI Protocol** | Governs AI behaviour within Plan phase; this protocol governs the workflow |
| **Gather Protocol** | Parent protocol; Plan is one phase within the overall Gather system |
| **Confirming Protocol** (future) | Receives the plan; adds Coordinators and assignments |
| **Freeze Protocol** (future) | Locks the plan; governs what can change after freeze |

---

## Appendix: State Diagram

```
                    ┌─────────────┐
                    │   (start)   │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │    DRAFT    │◀─────────────────────┐
                    └──────┬──────┘                      │
                           │                             │
            ┌──────────────┼──────────────┐              │
            │              │              │              │
            ▼              ▼              ▼              │
      ┌──────────┐  ┌──────────┐  ┌──────────┐          │
      │ Generate │  │  Manual  │  │  Check   │          │
      │   Plan   │  │   Edit   │  │   Plan   │          │
      └────┬─────┘  └────┬─────┘  └────┬─────┘          │
            │              │              │              │
            └──────────────┼──────────────┘              │
                           │                             │
                           ▼                             │
                    ┌─────────────┐                      │
                    │  Transition │──── blocked ─────────┘
                    │   Attempt   │
                    └──────┬──────┘
                           │
                       gate passes
                           │
                           ▼
                    ┌─────────────┐
                    │ CONFIRMING  │
                    └─────────────┘
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | January 2025 | Initial protocol |
