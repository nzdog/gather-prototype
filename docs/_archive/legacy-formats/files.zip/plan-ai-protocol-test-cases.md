# Plan AI Protocol — Test Cases & Enforcement Checklist

## Purpose

To translate the Plan AI Protocol's governance into enforceable artifacts: automated tests, code review checklist items, and QA scenarios. This document ensures implementation cannot drift from the protocol without detection.

## How to Use This Document

- **Automated tests**: Implement in test suite; run on every PR
- **Code review items**: Add to PR template; reviewer must verify before merge
- **QA scenarios**: Execute manually before each release; document results

---

## Theme 1: Draft, Never Decide

### Automated Tests

| ID | Rule | Test Description | Pass Criteria |
|----|------|------------------|---------------|
| 1.1 | No AI-initiated state change | Call all AI endpoints (generate, regenerate, check) and verify event status unchanged | Event `status` field identical before and after AI operation |
| 1.2 | State transitions require Host action | Attempt Draft→Confirming transition without Host action token | API returns 403 or equivalent rejection |
| 1.3 | Suggestions don't auto-apply | Generate plan, then fetch event items | Items table unchanged until explicit accept endpoint called |
| 1.4 | Accept endpoint requires explicit call | Verify no suggestion becomes part of plan without POST to `/accept` or equivalent | Plan state unchanged after generate/check until accept called |

### Code Review Checklist

- [ ] No endpoint changes event/plan status without explicit Host action parameter
- [ ] AI response objects never use past-tense action language ("added", "created", "assigned")
- [ ] All AI outputs return `draft: true` or equivalent flag
- [ ] UI components for AI suggestions include Accept/Modify/Dismiss controls

### QA Scenarios

| ID | Scenario | Steps | Expected Result |
|----|----------|-------|-----------------|
| 1.Q1 | Generate doesn't auto-save | 1. Create new event 2. Click Generate Plan 3. Close browser without accepting 4. Reopen event | Event has no items; draft was not persisted |
| 1.Q2 | Language audit | 1. Generate plan 2. Check plan 3. Review all AI text | No instance of "I've added", "I've created", "Done", or other finality language |

---

## Theme 2: Transparent Reasoning

### Automated Tests

| ID | Rule | Test Description | Pass Criteria |
|----|------|------------------|---------------|
| 2.1 | Source labelling present | Every suggestion object in API response | Contains `source` field with value from enum: `host_inputs`, `host_history`, `host_defaults`, `system_heuristics`, `aggregate_patterns` |
| 2.2 | Claim-type labelling present | Every suggestion object in API response | Contains `claimType` field with value from enum: `constraint`, `risk`, `pattern`, `preference`, `assumption` |
| 2.3 | Confidence level present | Every suggestion object in API response | Contains `confidence` field with value from enum: `definite`, `strong`, `moderate`, `weak`, `unknown` |
| 2.4 | Assumptions flagged | Generate plan with missing dietary input | At least one suggestion has `claimType: assumption` with `missingInput` field populated |
| 2.5 | Why-this endpoint exists | Call `/suggestion/{id}/explain` | Returns explanation object with `source`, `claimType`, `reasoning` fields |
| 2.6 | No source blending | Parse all explanation text | No explanation combines "your past events" and "similar gatherings" in same sentence without explicit distinction |

### Code Review Checklist

- [ ] Every new suggestion type includes source, claimType, and confidence fields
- [ ] Explanation text generation references specific inputs (guest count, dietary flags, etc.)
- [ ] No hardcoded explanation text that omits source attribution
- [ ] Assumptions explicitly name the missing input and the default used
- [ ] No external data sources added without protocol review

### QA Scenarios

| ID | Scenario | Steps | Expected Result |
|----|----------|-------|-----------------|
| 2.Q1 | Why-this affordance | 1. Generate plan 2. Click "Why this?" on any item | Explanation appears with visible source label and claim type |
| 2.Q2 | Assumption visibility | 1. Create event without dietary info 2. Generate plan | Suggestions show "Assumption" label with "Missing input: dietary requirements" |
| 2.Q3 | Source accuracy | 1. Complete two events 2. Create third event 3. Generate plan | Suggestions correctly distinguish "Your past events" vs "Similar gatherings" |

---

## Theme 3: Conflict Honesty

### Automated Tests

| ID | Rule | Test Description | Pass Criteria |
|----|------|------------------|---------------|
| 3.1 | Conflicts surfaced | Create plan with timing conflict (3 oven items, 1 oven declared) | Check Plan returns conflict object with `type: timing_conflict` |
| 3.2 | Severity labelling | All conflict objects in API response | Contains `severity` field with value from enum: `critical`, `significant`, `advisory` |
| 3.3 | Critical blocks transition | Attempt Draft→Confirming with unacknowledged Critical conflict | API returns 400 with `unacknowledged_critical_conflicts` error |
| 3.4 | Acknowledgement recorded | POST acknowledgement for Critical conflict, then retry transition | Transition succeeds; conflict marked `acknowledged: true` with timestamp |
| 3.5 | Dismissed conflicts don't repeat | Dismiss Significant conflict, run Check Plan again | Same conflict not returned (unless underlying input changed) |
| 3.6 | Input change resets dismissal | Dismiss timing conflict, add fourth oven item, run Check Plan | New conflict surfaced (different item count) |
| 3.7 | Manual addition conflict | Add manual item, request Regenerate with conflicting prompt | API returns conflict object with options before proceeding |

### Code Review Checklist

- [ ] All conflict detection logic assigns severity (Critical/Significant/Advisory)
- [ ] Critical conflicts require acknowledgement object before state transition
- [ ] Dismissal records include reference to input values at time of dismissal
- [ ] No silent conflict resolution (no auto-fix without Host action)
- [ ] Conflict explanations include claim type from Theme 2 taxonomy

### QA Scenarios

| ID | Scenario | Steps | Expected Result |
|----|----------|-------|-----------------|
| 3.Q1 | Critical acknowledgement flow | 1. Create plan with 0 vegetarian items, 6 vegetarian guests 2. Click "Move to Confirming" | Blocked with Critical conflict; requires acknowledgement text |
| 3.Q2 | Dismiss persistence | 1. Check Plan 2. Dismiss "structural imbalance" advisory 3. Check Plan again | Same advisory does not reappear |
| 3.Q3 | Input change resurfaces | 1. Dismiss timing conflict 2. Add another item at same time 3. Check Plan | New timing conflict appears (item count changed) |

---

## Theme 4: Proportional Confidence

### Automated Tests

| ID | Rule | Test Description | Pass Criteria |
|----|------|------------------|---------------|
| 4.1 | Quantity source bounded | Every quantity in generated plan | `quantitySource` field contains only: `host_inputs`, `host_history`, `host_defaults`, `system_heuristics`, `aggregate_patterns` |
| 4.2 | Quantity label present | Every quantity in generated plan | `quantityLabel` field with value from enum: `calculated`, `heuristic`, `placeholder` |
| 4.3 | No fabrication on missing data | Generate plan for novel item type with no history | Quantity marked `placeholder` with `basis: none` |
| 4.4 | Calculated quantities show work | Quantity marked `calculated` | Includes `calculation` field with formula and inputs |
| 4.5 | Strong language gating | Parse all suggestion text | "need", "must", "require" only appear when `claimType: constraint` AND `quantityLabel: calculated` |
| 4.6 | Heuristic version tracking | Quantity using system heuristic | Includes `heuristicVersion` field (e.g., "v1.0") |
| 4.7 | No external sources | Scan codebase for quantity generation | No HTTP calls to external APIs for "standard" quantities |

### Code Review Checklist

- [ ] New quantity logic uses only approved source types
- [ ] All heuristics added to system are versioned and documented
- [ ] No language escalation (Heuristic quantities cannot use "need"/"must")
- [ ] Placeholder quantities are explicitly flagged for Host action
- [ ] Uncertainty is stated, not hidden (no confident-sounding defaults)

### QA Scenarios

| ID | Scenario | Steps | Expected Result |
|----|----------|-------|-----------------|
| 4.Q1 | Heuristic transparency | 1. Generate plan for new Host (no history) 2. Review protein quantity | Shows "(Heuristic)" label, "Gather default v1.0", moderate language |
| 4.Q2 | Calculated accuracy | 1. Enter 48 guests 2. Generate plan | Calculated quantities show "48 × 150g = 7.2kg" or equivalent formula |
| 4.Q3 | Placeholder visibility | 1. Add custom item "Grandma's Secret Recipe" 2. Generate plan | Quantity shows "—" with "(Placeholder)" and "Enter quantity" action |

---

## Theme 5: Respectful Silence

### Automated Tests

| ID | Rule | Test Description | Pass Criteria |
|----|------|------------------|---------------|
| 5.1 | No unprompted suggestions | Load Plan view, wait 60 seconds, capture all network requests | No AI endpoint calls without user action |
| 5.2 | No WebSocket AI pushes | Monitor WebSocket during Plan phase idle | No AI suggestion payloads received |
| 5.3 | Gate check only on transition | Call transition endpoint with Critical conflicts | Returns block response; no prior notification was sent |
| 5.4 | Affordances are static | Inspect Generate/Check Plan buttons | No animation, pulse, badge, or dynamic styling |
| 5.5 | No state-based UI changes | Create plan with gaps, observe UI | No warning icons, red highlights, or progress bars appear without Check Plan invocation |

### Code Review Checklist

- [ ] No setTimeout/setInterval triggers for AI suggestions
- [ ] No "helpful tips" or onboarding nudges in Plan phase
- [ ] Button styling is static (no attention-grabbing animations)
- [ ] No AI judgment encoded in passive UI (colors, icons, progress)
- [ ] Gate checks implemented only on explicit transition endpoints

### QA Scenarios

| ID | Scenario | Steps | Expected Result |
|----|----------|-------|-----------------|
| 5.Q1 | Idle test | 1. Open Plan view 2. Do nothing for 30 minutes 3. Observe | Zero AI popups, tooltips, badges, or suggestions appear |
| 5.Q2 | Incomplete plan display | 1. Create plan with obvious gaps 2. Don't click Check Plan | UI shows data (empty teams, no items) without judgment indicators |
| 5.Q3 | Gate check timing | 1. Create plan with Critical conflict 2. Work for 20 minutes 3. Click "Move to Confirming" | First notification of conflict appears at transition, not before |

---

## Theme 6: Memory With Consent

### Automated Tests

| ID | Rule | Test Description | Pass Criteria |
|----|------|------------------|---------------|
| 6.1 | Host history scoping | Query history endpoint with Host A credentials | Returns only Host A events; zero Host B data |
| 6.2 | Cross-account isolation | Attempt to access Host B event ID with Host A token | Returns 403 or 404 |
| 6.3 | Aggregate anonymisation - no names | Inspect aggregate pattern data store | No item names, person names, venue names, free text |
| 6.4 | Aggregate minimum-N | Query aggregate with rare pattern (< threshold) | Returns null or "insufficient data" |
| 6.5 | Deletion completeness | Delete Host account, query all data stores | Zero records with Host ID remain |
| 6.6 | Source distinction in explanations | Generate suggestion using both Host history and aggregate | Response contains separate `sources` array entries, not blended |
| 6.7 | Consent flag respected | Set aggregate contribution to OFF, complete event | Event not included in next aggregate batch |
| 6.8 | View memory endpoint | Call `/host/memory` | Returns structured data: events, patterns, defaults, dismissals |
| 6.9 | Delete memory endpoint | Call DELETE `/host/memory/patterns` | Patterns removed; events retained |

### Code Review Checklist

- [ ] All Host data queries include Host ID filter at database level (not application level)
- [ ] No "super query" endpoints that span Host accounts
- [ ] Aggregate pipeline excludes free-text fields, names, specific dates
- [ ] Aggregate contribution checks consent flag before inclusion
- [ ] Memory deletion is immediate (no soft-delete or retention period)
- [ ] No Host data flows to marketing, analytics, or external systems
- [ ] New data usage requires protocol review

### QA Scenarios

| ID | Scenario | Steps | Expected Result |
|----|----------|-------|-----------------|
| 6.Q1 | First-use disclosure | 1. Create new Host account 2. Create first event | Disclosure message appears: "Gather learns from your events..." with visible toggle |
| 6.Q2 | Aggregate opt-in | 1. Complete first event 2. Observe | Invitation to contribute appears; default is OFF; can decline |
| 6.Q3 | View memory | 1. Complete two events 2. Go to Settings > Memory | See: event list, learned patterns, defaults, dismissed suggestions |
| 6.Q4 | Delete patterns | 1. View memory 2. Delete "Learned patterns" 3. Generate new plan | Suggestions no longer reference "Your past events" for deleted patterns |
| 6.Q5 | Full deletion | 1. Delete account 2. Admin query for Host ID | Zero records found anywhere |
| 6.Q6 | Coherence-safe prompt | 1. Host used 8 teams for 48 guests in 2024 2. Create event with 25 guests 3. Generate | AI suggests smaller structure with note: "Your past events used 8 teams for 48 guests — this event is smaller" |

---

## Cross-Theme Integration Tests

| ID | Themes | Test Description | Pass Criteria |
|----|--------|------------------|---------------|
| X.1 | 2+3 | Critical conflict uses correct claim type | Critical conflicts have `claimType: constraint` or `claimType: risk` (never `pattern` or `preference`) |
| X.2 | 2+4 | Quantity explanations include source and label | Every quantity explanation shows both `source` and `quantityLabel` |
| X.3 | 1+5 | Gate check is Host-initiated | Transition block occurs only after Host clicks transition button |
| X.4 | 2+6 | Memory-sourced suggestions labelled correctly | Suggestions from Host history show "Your past events"; aggregate shows "Similar gatherings" |
| X.5 | 3+5 | Critical conflicts don't nudge | Critical conflict exists but Check Plan not invoked | No UI indication until Host acts |
| X.6 | 4+6 | Historical quantities sourced correctly | Quantity derived from Host history shows `source: host_history`, not `aggregate_patterns` |

---

## Enforcement Integration

### PR Template Addition

```markdown
## Plan AI Protocol Compliance

- [ ] Theme 1: No AI-initiated state changes; draft language only
- [ ] Theme 2: All suggestions include source + claimType + confidence
- [ ] Theme 3: Conflicts include severity; Critical requires acknowledgement
- [ ] Theme 4: Quantities bounded to approved sources; labelled correctly
- [ ] Theme 5: No nudges, timers, or ambient AI presence added
- [ ] Theme 6: Host data scoped; no new data usage without review

If any box unchecked, explain:
```

### Pre-Release QA Checklist

```markdown
## Plan AI Protocol — Release QA

Version: ___________
Date: ___________
Tester: ___________

### Theme 1: Draft, Never Decide
- [ ] 1.Q1 Generate doesn't auto-save — PASS / FAIL
- [ ] 1.Q2 Language audit — PASS / FAIL

### Theme 2: Transparent Reasoning
- [ ] 2.Q1 Why-this affordance — PASS / FAIL
- [ ] 2.Q2 Assumption visibility — PASS / FAIL
- [ ] 2.Q3 Source accuracy — PASS / FAIL

### Theme 3: Conflict Honesty
- [ ] 3.Q1 Critical acknowledgement flow — PASS / FAIL
- [ ] 3.Q2 Dismiss persistence — PASS / FAIL
- [ ] 3.Q3 Input change resurfaces — PASS / FAIL

### Theme 4: Proportional Confidence
- [ ] 4.Q1 Heuristic transparency — PASS / FAIL
- [ ] 4.Q2 Calculated accuracy — PASS / FAIL
- [ ] 4.Q3 Placeholder visibility — PASS / FAIL

### Theme 5: Respectful Silence
- [ ] 5.Q1 Idle test (30 min) — PASS / FAIL
- [ ] 5.Q2 Incomplete plan display — PASS / FAIL
- [ ] 5.Q3 Gate check timing — PASS / FAIL

### Theme 6: Memory With Consent
- [ ] 6.Q1 First-use disclosure — PASS / FAIL
- [ ] 6.Q2 Aggregate opt-in — PASS / FAIL
- [ ] 6.Q3 View memory — PASS / FAIL
- [ ] 6.Q4 Delete patterns — PASS / FAIL
- [ ] 6.Q5 Full deletion — PASS / FAIL
- [ ] 6.Q6 Coherence-safe prompt — PASS / FAIL

### Cross-Theme
- [ ] X.1-X.6 Integration tests — PASS / FAIL

### Sign-off
All tests passed: YES / NO
Blockers: ___________
Approved for release: YES / NO
```

---

## Maintenance

This document must be updated when:
- New AI features are added to Plan phase
- Protocol themes are amended
- New conflict types or claim types are introduced
- Data sources for quantities change
- Memory/consent architecture changes

Owner: [Assign protocol owner]
Review cadence: Every major release or protocol change
