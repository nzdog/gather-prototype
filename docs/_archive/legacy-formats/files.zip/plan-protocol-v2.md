# Protocol: Plan

## Purpose

To govern the Plan phase of Gather — the phase where a Host (or two Hosts working together) constructs the complete coordination structure for a gathering before anyone else is invited.

## Why This Matters

A gathering succeeds or fails based on the quality of its plan. But "quality" isn't complexity — it's clarity. A good plan answers every coordination question before it's asked: who's responsible for what domain, what's needed, how much, when it happens. The Plan phase is where that clarity is built. If this phase is rushed, chaotic, or incomplete, every downstream phase inherits the confusion. Coordinators can't coordinate what isn't defined. Participants can't commit to what isn't clear.

## Use This When

- A Host is creating a new event in Gather
- Evaluating whether the Plan phase workflow is complete and coherent
- Debugging why a gathering's coordination broke down (trace back to planning)
- Onboarding Hosts to understand what "planning" means in Gather
- Deciding whether a feature belongs in Plan phase or a later phase

## Outcomes

- **Poor:** The Host creates a partial structure — teams without items, items without quantities, critical gaps unmarked. The plan moves forward with hidden fragility. Coordinators inherit confusion; participants inherit ambiguity. The gathering feels chaotic because it was never actually planned.

- **Expected:** The Host creates a complete structure with all teams, items, quantities, and critical flags defined. Gaps are identified and addressed before moving forward. The plan is stable enough that Coordinators can do their work without re-architecting.

- **Excellent:** The Host creates a plan that feels inevitable — the structure matches the gathering's reality so well that Coordinators and Participants experience it as obvious. The AI accelerates this without distorting it. The Host finishes planning feeling clear, not exhausted.

- **Transcendent:** The Plan becomes a reusable pattern. Next year's gathering starts from this year's learning. The Host's craft of gathering improves over time, supported by memory and structure. Planning becomes a calm ritual rather than a burden — something the Host looks forward to because it makes the gathering real.

---

## Themes

### 1. Event Creation _(Coherence)_

**Purpose:** To establish the foundational parameters of the gathering — what it is, when it happens, where it takes place, and who it's for.

**Why this matters:** Every downstream decision depends on these parameters. Guest count determines quantities. Venue determines constraints. Occasion type shapes structure. Without clear foundations, the AI guesses, the Host second-guesses, and the plan drifts.

**Outcomes:**

- Poor: Event is created with minimal information — just a name and date. Guest count is "maybe 40-50." Dietary needs are "we'll figure it out." The AI has nothing to work with; the Host has nothing to build on.
- Expected: Event has name, occasion type, dates, venue, guest count, and known dietary requirements. The AI can generate meaningful suggestions. The Host has a clear frame.
- Excellent: Event parameters are specific enough to constrain without over-specifying. The Host has captured what they know and flagged what they don't. Assumptions are visible, not hidden.
- Transcendent: Event creation becomes an act of clarity — the Host thinks through their gathering more deeply because the system asks good questions. The parameters become a reference point throughout planning.

**Guiding Questions:**

- Has the Host specified guest count (even if estimated)?
- Are known dietary requirements captured (vegetarian count, GF, DF, allergies)?
- Are venue constraints documented (kitchen equipment, timing restrictions, space limits)?
- Is occasion type selected (enabling relevant AI suggestions)?
- For multi-day events: are all days named with dates and venues?

**Completion Prompt:** Event parameters are defined with enough specificity that AI can generate meaningful suggestions and the Host has a clear foundation to build on.

---

### 2. Structure Generation _(Coherence)_

**Purpose:** To create the team and item structure that defines what needs to happen — either through AI generation, manual construction, or a combination.

**Why this matters:** Structure is the skeleton of the plan. Without teams, responsibility is diffuse. Without items, commitments are vague. This theme determines whether the Host starts from a blank page, an AI draft, or a template — and ensures the result is a complete, workable structure.

**Outcomes:**

- Poor: Structure is incomplete or incoherent. Teams overlap or leave gaps. Items lack quantities or timing. Critical items aren't marked. The skeleton can't support the gathering.
- Expected: Structure covers all coordination domains. Every team has a clear scope. Items have names, quantities, and timing where relevant. Critical items are flagged.
- Excellent: Structure matches the gathering's actual shape. Team count fits the scale. Items reflect real needs, not just defaults. The Host understands why each element exists.
- Transcendent: Structure generation becomes collaborative design — the Host and AI working together to imagine the gathering into existence. The structure feels discovered, not imposed.

**Guiding Questions:**

- Has the Host chosen a generation path (AI, manual, template, hybrid)?
- If AI-generated: did the Host review the draft rather than accepting blindly?
- If manual: has the Host considered using Check Plan to surface gaps?
- Are all responsibility domains covered by teams?
- Do items have quantities (or explicit placeholders)?
- Are critical items marked?
- Are manual additions tagged so regeneration can preserve them?

**Completion Prompt:** Team and item structure exists, covers all coordination domains, and has sufficient detail (quantities, timing, critical flags) for the next phase.

---

### 3. Refinement _(Coherence)_

**Purpose:** To iterate on the structure until it accurately reflects the gathering's needs — adding, removing, adjusting, and resolving conflicts.

**Why this matters:** First drafts are never final. The refinement loop is where the Host's knowledge meets the AI's suggestions and the plan becomes real. Skipping refinement means accepting defaults; over-refining means never finishing. This theme governs the productive middle.

**Outcomes:**

- Poor: No refinement occurs — the Host accepts the generated draft or builds once and stops. Gaps remain hidden. The plan doesn't reflect the actual gathering.
- Expected: Host makes meaningful edits — adjusting quantities, adding items, removing irrelevant suggestions. Check Plan is invoked at least once. Major issues are addressed.
- Excellent: Refinement is purposeful, not anxious. The Host knows when to adjust and when to stop. The AI's suggestions are evaluated, not just accepted or rejected. The plan converges on clarity.
- Transcendent: Refinement becomes craft. The Host develops judgment about what matters and what doesn't. Each gathering's planning makes the next one easier because the Host has learned, not just completed.

**Guiding Questions:**

- Has the Host invoked Check Plan at least once?
- Have AI suggestions been evaluated (not just accepted or dismissed reflexively)?
- Are placeholder quantities resolved or consciously left for later?
- Have conflicts been addressed (not just dismissed without reading)?
- Has the Host added anything the AI didn't suggest (local knowledge)?
- Does the structure feel complete to the Host, not just to the system?

**Completion Prompt:** The plan has been refined through at least one Check Plan cycle, conflicts have been addressed, and the Host is confident the structure reflects the gathering's actual needs.

---

### 4. Conflict Resolution _(Coherence)_

**Purpose:** To surface and resolve tensions in the plan before they become execution failures — ensuring the Host consciously addresses contradictions rather than inheriting them.

**Why this matters:** Every plan contains tensions: too many oven items for one oven, dietary requirements without matching options, uneven team loads. Unresolved conflicts become crises on the day. This theme ensures conflicts are visible and consciously handled.

**Outcomes:**

- Poor: Conflicts are ignored, dismissed without reading, or never surfaced because Check Plan wasn't invoked. The Host discovers problems during execution.
- Expected: Check Plan surfaces conflicts. The Host reads them, resolves what can be resolved, and acknowledges what they're choosing to accept. Critical conflicts require explicit acknowledgement.
- Excellent: Conflict resolution becomes preventive design. The Host adjusts the plan to eliminate tensions rather than just acknowledging them. The plan is robust, not just complete.
- Transcendent: The Host develops a feel for where tensions hide. They anticipate conflicts before the AI flags them. Planning becomes a form of risk management that feels natural, not bureaucratic.

**Guiding Questions:**

- Has Check Plan been invoked to surface conflicts?
- Are Critical conflicts resolved or explicitly acknowledged (with recorded acknowledgement text)?
- Are Significant conflicts addressed or consciously dismissed?
- Does the Host understand why each conflict was flagged?
- Have timing conflicts been resolved (not just noted)?
- Have dietary gaps been closed (or acknowledged with impact understood)?

**Completion Prompt:** All Critical conflicts are resolved or explicitly acknowledged; Significant and Advisory conflicts have been reviewed and consciously handled.

---

### 5. Gate Transition _(Coherence)_

**Purpose:** To ensure the plan is genuinely ready before Coordinators and Participants are brought in — making the transition from planning to coordination a conscious threshold, not an accidental drift.

**Why this matters:** Once the plan moves to Confirming, other people depend on it. Coordinators will assign items. Participants will make commitments. A premature transition exports confusion. A stuck transition wastes momentum. The gate must be meaningful but not obstructive.

**Outcomes:**

- Poor: The Host clicks through the transition without the plan being ready, or gets stuck at the gate without understanding why. The transition is either meaningless or frustrating.
- Expected: The gate blocks on unacknowledged Critical conflicts. The Host addresses them or acknowledges them consciously. The transition happens when the plan is actually ready.
- Excellent: The Host experiences the gate as helpful — a final check that catches what they might have missed. Passing the gate feels like a legitimate milestone, not a bureaucratic hurdle.
- Transcendent: The transition becomes a moment of commitment. The Host crosses from "imagining the gathering" to "making it happen." The plan phase ends with clarity and confidence.

**Guiding Questions:**

- Has the Host attempted the transition?
- If blocked: does the Host understand what's blocking and how to resolve it?
- Are all Critical conflicts acknowledged (with acknowledgement recorded)?
- Does the plan meet structural minimums (at least one team, at least one item)?
- Is the Host confident that Coordinators can work from this structure?
- Has the Host mentally shifted from "planning" to "coordinating"?

**Completion Prompt:** The gate check passes (or Critical conflicts are explicitly acknowledged), and the plan transitions to Confirming with the Host confident that the structure is ready for Coordinators.

---

### 6. Template & Memory _(Coherence)_

**Purpose:** To connect this plan to past and future gatherings — enabling learning across events and reducing the burden of starting from scratch.

**Why this matters:** Most Hosts run similar gatherings repeatedly. Christmas happens every year. Family reunions recur. Without templates and memory, each planning cycle starts cold. With them, each cycle builds on the last. This theme governs how planning compounds.

**Outcomes:**

- Poor: Every event starts from zero. The Host doesn't use templates or their own history. Past learning is lost. Planning is perpetually effortful.
- Expected: Templates exist and are used. Host history informs suggestions. The Host can clone last year's event and adapt it.
- Excellent: Templates become a personal library. The Host's planning improves year over year because Gather remembers what worked. Adaptation is easy; starting over is rare.
- Transcendent: Memory serves coherence, not habit. The AI helps the Host adapt when circumstances change rather than blindly repeating past patterns. The Host's craft grows because the system supports growth.

**Guiding Questions:**

- Is the Host starting from a template or past event (where appropriate)?
- If cloning: has the Host adapted for changed circumstances (different guest count, venue, etc.)?
- Has the AI surfaced relevant divergence ("last year was 48 guests; this year is 30")?
- Does the Host know they can save this event as a template?
- Is Host memory being used to inform suggestions (with consent)?
- Is the Host over-relying on templates (fossilisation) or appropriately adapting?

**Completion Prompt:** The plan appropriately uses templates and Host history where relevant, adapts for changed circumstances, and the Host knows they can save this structure for future use.

---

## Completion Prompts

- Event parameters are defined (name, occasion, dates, venue, guests, dietary requirements)
- Team and item structure is complete with quantities, timing, and critical flags
- Check Plan has been invoked at least once
- All Critical conflicts are resolved or explicitly acknowledged
- Significant and Advisory conflicts have been consciously handled
- The gate check passes and the plan transitions to Confirming
- The Host is confident Coordinators can work from this structure
- Template/memory has been appropriately used (or consciously skipped for new gatherings)
